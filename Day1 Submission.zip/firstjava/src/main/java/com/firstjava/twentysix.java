package com.firstjava;

import java.util.Scanner;

public class twentysix {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number");
		double x=sc.nextDouble();
		System.out.println(x*x);
	}

}
