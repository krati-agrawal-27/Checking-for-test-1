package com.firstjava;

import java.util.Scanner;

public class Hello {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     int a,b,c;
     Scanner sc=new Scanner (System.in);
     a=sc.nextInt();
     b=sc.nextInt();
     //a=5;
     //b=10;
     c=a+b;
     System.out.println(c);
	}

}
