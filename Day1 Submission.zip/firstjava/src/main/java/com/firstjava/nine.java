package com.firstjava;

public class nine {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=2;
		System.out.println(0);
for(int i=0;i<6;i++) {
	System.out.print(0+" ");
	
	for(int j=1;j<=i+1;j++) {
		System.out.print(x*j +" ");
	}
	x=x+1;
	System.out.println();
}
	}

}
