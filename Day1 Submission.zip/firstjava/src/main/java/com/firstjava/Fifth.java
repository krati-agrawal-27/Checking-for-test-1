package com.firstjava;
import java.util.Scanner;
//import java.util.*;
public class Fifth {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	Scanner sc=new Scanner(System.in);
	System.out.println(" Input a number of which you want table");
	int a=sc.nextInt();
	for(int i=1;i<11;i++) {
		System.out.println(a*i);
	}
			
	}

}
