package com.firstjava;

public class thirtytwo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a[]= {1,2,3,4};
int b[]=a.clone();
for(int i=0;i<4;i++)
System.out.println(b[i]);
	}

}
