package com.firstjava;

public class twelve {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
for(int i=1;i<11;i++) {
	int x=cube(i);
	System.out.println(x);
}
	}
	static int cube(int i) {
		return i*i*i;
	}

}
